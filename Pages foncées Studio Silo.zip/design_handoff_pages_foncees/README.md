# Handoff : pages foncées Studio Silo (nouvelle D.A.)

## Vue d'ensemble
Refonte de la direction artistique des **trois sections foncées** du site one-page Studio Silo
(`index.html` du dépôt « Website v1ise ») :

| Section du site | id | Nouveau traitement |
|---|---|---|
| Constat | `#constat` | Titre XXL + rail de cartes photo plein cadre, débordant à droite |
| Ce que dit la littérature | `#chiffres` | Même rail, cartes chiffres + une carte photo de fin |
| Derrière Studio Silo | `#qui` | Photo studio plein fond masquée + galerie de plans arrêtés |
| Footer | `footer` | Inchangé dans la structure, fond `#0E0D0C` |

Le contenu (titres, textes, chiffres, sources, liens) est **repris à l'identique** de `index.html` :
rien à réécrire, seule la mise en forme change.

**S'applique aussi aux sections claires.** La D.A. photo ne concerne que les sections foncées,
mais la **règle de hauteur** ci-dessous (§ « Rythme vertical : une section = un écran ») doit être
appliquée à **toutes** les sections du site, claires comprises (`#hero`, `#intro`, `#quotidien`,
`#reponse`, `#conformite`, `#etapes`, `#exploration`) : chaque section tient dans un écran et son
bouton de suite est visible **sans scroller**.

## À propos des fichiers de ce dossier
`Pages foncées.dc.html` est une **référence de design en HTML** — un prototype qui montre
l'intention visuelle et les interactions, **pas du code à copier tel quel** dans le site.
Il s'ouvre directement dans un navigateur (il charge `support.js`, présent dans ce dossier).

La tâche côté Claude Code : **re-créer ces écrans dans l'environnement existant du site**, c'est-à-dire
`index.html` — un fichier unique, sans build, sans framework, avec un `<style>` en ligne et des
variables CSS dans `:root`. Il faut donc traduire le prototype en **classes CSS ajoutées au `<style>`
existant**, en réutilisant les tokens déjà là (`--night`, `--kraft`, `--gut`, `--maxw`, `--ease`…),
et non en collant des styles en ligne.

## Fidélité
**Haute fidélité (hifi)** : couleurs, typographie, espacements et interactions sont définitifs.
À reproduire au pixel près, en conservant le HTML sémantique existant (`section.panel`, `article.slide`,
`article.stat`, etc.) partout où c'est possible.

---

## Design tokens

### Couleurs
| Rôle | Valeur | Note |
|---|---|---|
| Fond principal foncé | `#131211` | remplace `--night #1E1B18` sur les pages foncées |
| Fond dégradé haut de page (Constat) | `radial-gradient(85% 60% at 50% -5%, #242019 0%, #131211 60%)` | |
| Fond dégradé (Chiffres) | `radial-gradient(75% 60% at 18% 0%, #221E19 0%, #161413 58%)` | |
| Fond carte photo | `#0F0E0C` | sous l'image |
| Fond footer | `#0E0D0C` | |
| Texte titre | `#FFFDF9` | |
| Texte courant | `#F3EBDD` | = `--paper` du site |
| Texte sur photo | `#F6F1E8` | + `text-shadow: 0 1px 16px rgba(10,9,8,.6)` |
| Texte secondaire | `rgba(243,235,221,.72)` | |
| Texte tertiaire / légendes | `rgba(237,228,214,.5)` | |
| Accent (chiffres, pastilles, CTA plein) | `#CFB498` (`--kraft`) | tweakable |
| Surlignage « les acteurs de la santé » | `rgba(120,126,120,.5)` | équivalent de `--marker` |
| Bordure carte | `rgba(237,228,214,.2)` | |
| Fond carte chiffre | `rgba(255,255,255,.035)` | |
| Barre flottante | `rgba(95,82,68,.5)` + `backdrop-filter: blur(16px) saturate(140%)` | |

### Typographie — Neue Montreal (déjà dans le dépôt, `assets/fonts/`)
| Élément | Taille | Graisse | Interlettrage | Interligne |
|---|---|---|---|---|
| H1 page (« L'hémorragie silencieuse ») | `clamp(40px,6.4vw,104px)` | 700 | `-.045em` | `.94` |
| Sous-titre H1 | `clamp(19px,2.2vw,34px)` | 500 | `-.03em` | `1.1` |
| H2 section (« Le goulot… ») | `clamp(28px,3.7vw,62px)` | 700 | `-.04em` | `.97` |
| Titre de carte photo | `clamp(19px,1.85vw,29px)` | 700 | `-.03em` | `1.05` |
| Chapô / lead | `clamp(14px,1.05vw,18px)` | 400 | `-.012em` | `1.35` |
| Gros chiffre (court) | `clamp(32px,3.4vw,66px)` | 700 | `-.05em` | `.9` |
| Gros chiffre (long, > 6 car.) | `clamp(24px,2.3vw,46px)` | 700 | `-.05em` | `.9` |
| Étiquette parcours / n° de carte | `12px` / `12.5px` | 500 | `.02em` / `.04em` | — |
| Périmètre + source | `11px` / `12.5px` | 400 | — | `1.3` |
| Italique de titre (« un humain disponible. ») | hérite | 400 | `0` | — |

Italique = `'EB Garamond', Garamond, 'Times New Roman', serif` (`--serif` existant, non chargée : fallback système, identique au site actuel).

### Formes, espacements, ombres
- Rayon carte : **26px** (`--r`, tweakable 0–40). Galerie de plans arrêtés : **14px**. Pilules : `999px`.
- Rayon haut de section empilée : `34px 34px 0 0` + `box-shadow: 0 -22px 50px rgba(0,0,0,.45)` (reprend `.panel.sheet`).
- Gouttière de page : `clamp(20px,6vw,104px)` (= `--gut`), largeur max contenu : `1520px` (= `--maxw`).
- Rythme vertical : voir la section dédiée ci-dessous.
- Gap du rail : `16px` (Constat) / `14px` (Chiffres).
- Transitions : `.25s` sur les fonds de boutons, `.4s ease` sur les révélations au survol,
  easing du site : `cubic-bezier(.2,.7,.2,1)` (`--ease`).

---

## Rythme vertical : une section = un écran (claires **et** foncées)

Règle transversale, la plus importante de cette itération : **aucune section ne doit dépasser la
hauteur de l'écran**, pour que la pilule « suite » de chaque section soit visible sans scroller
(modèle Apple : on avance de section en section, jamais en cherchant un bouton hors champ).

### Recette
```css
.panel{                       /* toutes les sections, claires comprises */
  min-height:100svh;          /* svh, pas vh : évite la barre d'URL mobile */
  display:flex;
  align-items:center;         /* contenu centré verticalement */
}
.panel > .in{
  width:100%;
  padding-block:clamp(76px,11svh,150px) clamp(18px,3svh,56px);
  justify-content:center;
}
```
- `box-sizing:border-box` est **indispensable** (déjà global dans `index.html`), sinon le padding
  s'ajoute aux `100svh` et la section fait systématiquement ~100 px de trop.
- Les valeurs verticales doivent être **proportionnelles** : `svh` dans les `clamp()`
  (`clamp(14px,2.4svh,36px)`, `clamp(12px,2svh,38px)`…) et **plancher bas**, sinon ce sont les
  minimums en px qui gagnent sur petit écran et la section déborde.
- Les blocs qui portent la hauteur (cartes, visuels, frises) se dimensionnent en `svh`, jamais en
  ratio fixe : `min-height:clamp(140px,34svh,440px)` + `display:flex` avec enfant `flex:1`
  (un `aspect-ratio` fixe coupe le contenu, un `height:100%` d'enfant crée une dépendance cyclique).

### Ce que ça implique section par section (sections claires)
| Section | Levier principal pour tenir dans l'écran |
|---|---|
| `#intro` (Chez vous) | Cartes parcours en 3 colonnes, description 2 lignes max (`-webkit-line-clamp:2`), note de bas de bloc en `13px` |
| `#quotidien` | La frise « journée type » et la calculette sont **deux écrans distincts**, chacun avec son bouton de suite |
| `#reponse` | Tableau frictions/vidéo : `padding` des lignes en `clamp(10px,1.4svh,18px)`, le bloc « Nos vidéos sont » passe à l'écran suivant si besoin |
| `#conformite` | Déjà court : centrer verticalement suffit |
| `#etapes` | 6 étapes sur une ligne en desktop, descriptions 3 lignes max |
| `#exploration` | Formulaire en 2 colonnes, champs `height:44px`, le bouton d'envoi doit rester au-dessus de la ligne de flottaison |

### Critère d'acceptation (à vérifier avant de livrer)
Pour **chaque** section, à 1440×900 **et** à 1280×720 :
```js
const s = document.querySelector('#etapes');            // et ainsi de suite
s.getBoundingClientRect().height <= innerHeight;        // → true
const b = [...s.querySelectorAll('a,button')].pop();    // bouton de suite
b.getBoundingClientRect().bottom - s.getBoundingClientRect().top <= innerHeight;  // → true
```
Si une section ne peut pas tenir sans sacrifier du contenu, la **couper en deux sections** (chacune
avec son bouton) plutôt que la laisser déborder.

---

## Écrans

### 1. Constat (`#constat`)
**Objectif** : poser le constat en une lecture, sans scroll.

Structure (de haut en bas) :
1. `h1` « L'hémorragie silencieuse » (aligné à gauche, gouttière).
2. Ligne « chez <mark>les acteurs de la santé</mark> » — le surlignage est un `<span>` avec
   fond `rgba(120,126,120,.5)`, `padding:.02em .08em`, `box-decoration-break:clone`
   (remplace l'animation `.mk` du site, qui peut être conservée si vous préférez).
3. **Rail horizontal** : `display:flex; overflow-x:auto; scroll-snap-type:x mandatory`,
   marge droite négative `calc(-1 * var(--gut))` pour déborder du cadre (effet Apple).
   - Carte 1 (manifeste) : `flex:0 0 min(58%,880px)`, photo `infirmiere-perroquet.jpg`
     (`object-position:50% 45%`), voile `linear-gradient(180deg,rgba(15,14,12,.34),rgba(15,14,12,.18) 40%,rgba(15,14,12,.5))`,
     texte centré (max `36ch`) + bouton « Regarder la vidéo ».
   - Cartes 2-4 (les trois fuites) : `flex:0 0 min(31%,470px)`, n° `01/02/03` en haut à gauche,
     titre centré ; **la description apparaît au survol** (`opacity 0 → 1`, `translateY(6px → 0)`).
   - Hauteur commune : `min-height:clamp(140px,34svh,440px)`, la carte grandit si son contenu
     dépasse (`display:flex` + enfant `flex:1` — surtout **pas** d'`aspect-ratio` fixe, ça coupe le contenu).
   - Images : `filter: brightness(var(--photo,.55)) saturate(.85) contrast(1.04)`.
4. Ligne de pied : « Trois fuites, une même réponse… » à gauche, « Glissez pour parcourir » à droite.
5. Pilule centrée **« Les 5 parcours »** → `#intro`.

### 2. Ce que dit la littérature (`#chiffres`)
1. Pastille `Ce que dit la littérature` (fond `#EDE4D6`, texte `#1E1B18`, hauteur 36px).
2. Bloc titre en deux colonnes (`grid-template-columns: repeat(auto-fit,minmax(min(100%,340px),1fr))`) :
   H2 à gauche, chapô à droite (4 lignes max, `-webkit-line-clamp:4`).
3. Barre de filtres : pilules `Tous / Parcours patient / Onboarding soignant / Prescripteur /
   Déploiement B2B / Support & SAV`, **sur une seule ligne scrollable** (`flex-wrap:nowrap; overflow-x:auto`),
   état actif = fond `#EDE4D6`, texte `#1E1B18`. À droite, deux boutons ronds 44px (← →) qui font
   défiler le rail d'une carte.
4. Rail de cartes chiffre : `flex:0 0 clamp(268px,25vw,410px)`, bordure `1px rgba(237,228,214,.2)`,
   fond `rgba(255,255,255,.035)`, contenu : gros chiffre accent → (étiquette parcours + badge
   « Étude / Donnée sectorielle / Donnée institutionnelle » sur la même ligne) → affirmation
   (4 lignes max) → périmètre (2 lignes max, poussé en bas par `margin-top:auto`) → lien source
   avec pastille accent 7px, séparé par un filet haut.
   Dernière carte du rail = carte photo (`realisation-03.jpg`) « Chaque friction se colmate avec un
   parcours vidéo. » + pilule « Voir la méthode ».
5. Pied : compteur « N chiffres » + filet + « Cliquez une source pour ouvrir l'étude. »
6. Pilule centrée **« Notre méthode »** → `#etapes`.

Le filtrage se fait sur l'attribut `data-parcours` déjà présent sur chaque `article.stat` du site.

### 3. Derrière Studio Silo (`#qui`)
1. Photo `studio-schmidt.jpg` en fond, `height:min(105vh,1000px)`, `object-position:8% 42%`,
   `opacity:.4`, `filter: grayscale(.7) sepia(.25) brightness(.72) contrast(1.06)`,
   masque `linear-gradient(180deg,#000 40%,transparent 100%)` (c'est le `.bgp-qui` existant, assombri).
2. Pastille « Derrière Studio Silo », puis bloc texte `max-width:62ch` : `Schmidt Basile`,
   rôle en italique serif, deux paragraphes, CTA plein accent « Commençons par une session d'exploration ».
3. Filet, puis bloc « La qualité comme signature, depuis toujours. » + chapô.
4. **Galerie justifiée** de plans arrêtés : `display:flex; flex-wrap:wrap; gap:10px`,
   chaque tuile `flex: (ratio×100) 1 (ratio×200px)` et `aspect-ratio: ratio`, rayon 14px
   (même principe que `.gallery .tile` du site, ratios : 2.02 / 0.54 / 2.04 / 0.66 / 2.03 / 2.03).
5. Encart confidentialité : bordure `rgba(237,228,214,.2)`, fond `rgba(255,255,255,.04)`,
   pilule contour « Demander à voir des extraits » + lien e-mail.

### Barre flottante
Pilule centrée, `position:sticky; top:0` dans un conteneur `height:0` (dans le site : garder
`position:fixed` de `.bar`). Logo en blanc (`filter: brightness(0) invert(1)`), 3 liens, CTA
accent « Nous contacter » avec pastille `#141312` et flèche. Lien actif : fond `#EDE4D6`, texte `#1E1B18`.

### Bouton « pilule à pastille » (motif central de la D.A.)
```
contour  : 1.5px solid rgba(246,241,232,.85)   | plein : background #CFB498, color #141312
hauteur  : clamp(44px,3.8vw,52px)  (58px pour le CTA vidéo)
padding  : 0 5px 0 22px      gap : 14px      radius : 999px
pastille : cercle 34–42px #F6F1E8  (pilule 52×34 → 66×42 pour « Regarder la vidéo »)
hover    : background rgba(246,241,232,.14)  (plein : #E3CFB2)
```

---

## Interactions & comportement
- **Rails** : scroll tactile/trackpad, `scroll-snap-align:start`, flèches ← → (Chiffres) qui décalent
  d'une largeur de carte + gap (`scrollBy({left, behavior:'smooth'})`). Barres de défilement masquées.
- **Survol des cartes photo** (Constat) : la description passe de `opacity:0 / translateY(6px)` à
  `opacity:1 / translateY(0)` en `.4s`. Désactivable (prop `revealOnHover`) → descriptions toujours visibles.
- **Filtres chiffres** : re-rendu de la liste filtrée + mise à jour du compteur.
- **Nav active** : `IntersectionObserver` avec `rootMargin:'-45% 0px -50% 0px'` ; ne déclencher le
  changement d'état **que si la valeur change** (sinon boucle de rendu).
- **Sources** : `target="_blank" rel="noopener"`.
- `prefers-reduced-motion` : supprimer les transitions de survol et le `scroll-behavior:smooth`
  (le site a déjà la règle globale).

## État
`activeSection` (string) · `tabParcours` (string, défaut `all`) · `hoveredCard` (0-3) ·
position de scroll de chaque rail (DOM, pas d'état React nécessaire).

## Variables exposées (réglages)
| Variable CSS | Défaut | Usage |
|---|---|---|
| `--accent` | `#CFB498` | chiffres, pastilles, CTA plein |
| `--photo` | `0.55` | luminosité des photos (`filter: brightness()`) |
| `--r` | `26px` | rayon des cartes |

## Assets (tous dans `assets/`, copiés depuis le dépôt Website v1)
- Polices : `NeueMontreal-Regular/Medium/Bold/Italic.otf`
- Logo : `logo-studiosilo.svg` (à inverser en blanc via `filter`)
- Photos : `infirmiere-perroquet.jpg`, `perroquet.jpg`, `studio-schmidt.jpg`,
  `gallery/realisation-01,02,03,04,07,08,09.jpg`, `hero-silo-1200.jpg`, `portrait-schmidt-basile.jpg`

## Fichiers de ce dossier
- `screenshots/` — 01 Constat, 02 Chiffres, 03 Derrière Studio Silo, 04 Galerie + footer
- `Pages foncées.dc.html` — le prototype (à ouvrir dans un navigateur)
- `support.js` — runtime nécessaire au prototype uniquement (**ne pas** l'intégrer au site)
- `assets/` — polices et images

---

## Comment travailler avec Claude Code

1. Placez ce dossier à la racine du dépôt du site (à côté de `index.html`), par ex.
   `design_handoff_pages_foncees/`.
2. Lancez `claude` dans le dépôt et collez ce prompt :

> Lis `design_handoff_pages_foncees/README.md` puis ouvre
> `design_handoff_pages_foncees/Pages foncées.dc.html` comme **référence visuelle**.
> Applique cette direction artistique aux trois sections foncées de `index.html`
> (`#constat`, `#chiffres`, `#qui`) et au `footer`, **sans changer la D.A. des sections claires**
> (`#hero`, `#intro`, `#quotidien`, `#reponse`, `#conformite`, `#etapes`, `#exploration`)
> ni les textes, chiffres et sources existants.
> Applique en revanche la règle « une section = un écran » du README à **toutes** les sections,
> claires comprises : chaque section fait `min-height:100svh`, contenu centré, et son bouton de
> suite est visible sans scroller (vérifie le critère d'acceptation à 1440×900 et 1280×720).
> Contraintes : un seul `index.html`, pas de build, pas de framework ; ajoute tes règles dans le
> `<style>` existant en réutilisant les variables de `:root` (ajoute `--night-deep:#131211`) ;
> garde les classes et la structure HTML actuelles quand c'est possible ; conserve
> l'accessibilité (focus visibles, `aria-*`, `prefers-reduced-motion`).
> Commence par me proposer un plan section par section avant d'éditer.

3. Points de vigilance à rappeler à Claude Code si besoin :
   - `box-sizing:border-box` est déjà global dans `index.html` → les `min-height:100svh` se comportent bien.
   - Les sections foncées sont des `.panel` **sticky** empilés : la hauteur d'écran se règle sur
     `min-height:100svh` du `.panel`, et le contenu est centré via `.panel > .in { justify-content:center }`.
   - Le rail doit garder `overscroll-behavior-x: contain` (déjà utilisé par `.stats` / `.rail`) pour ne pas
     déclencher le retour arrière du navigateur.
   - Ne pas dupliquer les données des chiffres : elles sont déjà dans le HTML (`article.stat[data-parcours]`).
